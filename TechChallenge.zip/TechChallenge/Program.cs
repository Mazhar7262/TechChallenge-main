﻿using TechChallenge.Common.Infrastructure.Dto;
using TechChallenge.Exporters.Infrastructure.Services;

namespace TechChallenge;

class Program
{
	static void Main(string[] args)
	{
		Task t = MainAsync(args);
		t.Wait();
	}

	static async Task MainAsync(string[] args)
	{
		// Step1: All payments 
		var allPayments = TechChallenge.Common.Infrastructure.Helpers.TechChallengeHelper.Payments;

		var validationDictionary = new Dictionary<int, List<string>>();

		//Change this to change the bank being used
		//const string selectedBank = "BankOfIreland";
		const string selectedBank = "JPMorgan";

		Console.WriteLine($"Selected Bank: {selectedBank}");

		var paymentsForBank = await SelectPaymentsForBankAsync(selectedBank, allPayments);
		var validPaymentsForBank = await ValidatePaymentsForBankAsync(selectedBank, validationDictionary, paymentsForBank);
		OutputValidationDictionary(validationDictionary);

		Console.WriteLine($"Total payments with validation errors: {validationDictionary.Count}");
		Console.WriteLine($"Total payments to be exported: {validPaymentsForBank.Count}");

		var filename = await ExportPaymentsForBankAsync(selectedBank, validPaymentsForBank);
		Console.WriteLine($"Destination file: {filename}");

		var text = await File.ReadAllTextAsync(filename);
		Console.WriteLine(text);

		PressAKeyToContinue();
	}

	private static async Task<List<Payment>> ValidatePaymentsForBankAsync(string selectedBank, Dictionary<int, List<string>> validationDictionary,
			List<Payment> paymentsForBank)
	{
		//This method should call the relevant export service's ValidatePayments method providing the validation dictionary 
		//and paymentsForBank.  The method should then populate validationDictionary with any errors for specific payments
		//and return only those payments for the bank that are valid.
		var validPayments = new List<Payment>();
		if (selectedBank == "BankOfIreland")
			validPayments = await BankOfIrelandPaymentExporter.ValidatePaymentsAsync(paymentsForBank, validationDictionary);
		else if (selectedBank == "JPMorgan")
			validPayments = await JPMorganPaymentExporter.ValidatePaymentsAsync(paymentsForBank, validationDictionary);
		return validPayments;
	}



	private static async Task<string> ExportPaymentsForBankAsync(string selectedBank, List<Payment> validPaymentsForBank)
	{
		//This method should call the relevant export service's ExportPayments method providing validPaymentsForBank
		//The ExportPayments method should create a file of the required format and return its filename
		var result = string.Empty;
		if (selectedBank == "BankOfIreland")
			result = await BankOfIrelandPaymentExporter.ExportPaymentsAsync(validPaymentsForBank);
		else if (selectedBank == "JPMorgan")
			result = await JPMorganPaymentExporter.ExportPaymentsAsync(validPaymentsForBank);
		return result;
	}

	private static async Task<List<Payment>> SelectPaymentsForBankAsync(string selectedBank, List<Payment> allPayments)
	{
		//This method should create the relevant exporter call its SelectPaymentsForBankAsync method providing payments
		var selectedPayments = new List<Payment>();
		if (selectedBank == "BankOfIreland")
			selectedPayments = await JPMorganPaymentExporter.ExtractPaymentsAsync(selectedBank, allPayments);
		else if (selectedBank == "JPMorgan")
			selectedPayments = await JPMorganPaymentExporter.ExtractPaymentsAsync(selectedBank, allPayments);
		return selectedPayments;
	}

	private static void OutputValidationDictionary(Dictionary<int, List<string>> validationDictionary)
	{
		foreach (var entry in validationDictionary)
		{
			var payment = entry.Key;

			Console.WriteLine($"Validation Errors for payment number: {payment}");
			foreach (var text in entry.Value)
			{
				Console.WriteLine(text);
			}

			Console.WriteLine();
		}

		PressAKeyToContinue();
	}

	private static void PressAKeyToContinue()
	{
		Console.WriteLine("Press a key to continue");
		Console.ReadKey();
	}
}